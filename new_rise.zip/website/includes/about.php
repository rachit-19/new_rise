<section class="about-section">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/pattern-1.png);"></div>
            <div class="auto-container">
                <div class="row align-items-center clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div id="image_block_1">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/about-1.jpg" alt=""></figure>
                                <div class="box">
                                    <div class="inner">
                                        <div class="icon-box">
                                            <div class="icon icon-1"></div>
                                            <div class="icon icon-2"></div>
                                        </div>
                                        <span>Canada's Leading Visa & Immigration lawyers with</span>
                                        <h1>24</h1>
                                        <p>Years Of Experience</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div id="content_block_1">
                            <div class="content-box">
                                <div class="sec-title">
                                    <p>who are new rise immigration</p>
                                    <h2>Not Just Traditional Visa & Immigration Firm</h2>
                                    <div class="dotted-box">
                                        <span class="dotted"></span>
                                        <span class="dotted"></span>
                                        <span class="dotted"></span>
                                    </div>
                                </div>
                                <div class="bold-text">
                                    <p>At New rise Immigration, we believe in progress with passion. </p>
                                </div>
                                <?php
                                    if($page_name == "About"){
                                ?>
                                <div class="text">
                                    <p>Our team of licensed Immigration consultants and career counselors is always willing to transcend, to ensure that your immigration goals are met. Here at New rise, we like to sit and talk with you one on one to know your immigration needs and provide you with tailored and customized solutions that make moving abroad seamless.</p>
                                    <p>Here at New rise, we like to sit and talk with you one on one to know your immigration needs and provide you with tailored and customized solutions that make moving abroad seamless.</p>
                                    <p>We at New Rise Immigration understand that moving abroad sometimes is a lengthy and tedious process, hence we try to be there for you at every step. Our immigration process is designed to help any individual requiring a student visa, permanent residence, or visitor visa. when you arrive in Canada( your new home ), we will ensure that you are Canada-ready and have all the important information and contacts to different government and private organizations that will help you smoothly transition and settle in Canada.</p>
                                </div>
                                <?php } ?>
                                <?php
                                    if($page_name == null || $page_name == "Home"){
                                ?>
                                <div class="text">
                                    <p>Our team of licensed Immigration consultants and career counselors is always willing to transcend, to ensure that your immigration goals are met. Here at New rise, we like to sit and talk with you one on one to know your immigration needs and provide you with tailored and customized solutions that make moving abroad seamless.</p>
                                    
                                </div>
                                <?php } ?>
                                <?php
                                    if($page_name == null || $page_name == "Home"){
                                ?>
                                <div class="btn-box">
                                    <a href="about.php" class="theme-btn-two">Learn More<i class="flaticon-send"></i></a>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <?php
                        if($page_name == "About"){
                    ?>
                    <div class="col-lg-12 ml-3 col-md-12 col-sm-12 content-column">
                        <div id="content_block_1">
                            <div class="content-box mt-5">
                                <p>New Rise immigration services, stand by its core values of honesty and integrity, where your success and happiness matter the most. As a proud Canadian immigration consulting company, we are passionate to help you understand Canadian Immigration and how Canada could be the answer to all your future needs and goals.</p>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </section>
     