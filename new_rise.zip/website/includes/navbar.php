<header class="main-header style-one">
            <div class="header-top">
                <div class="top-inner clearfix">
                    <div class="top-left pull-left">
                        <ul class="info clearfix d-none d-sm-block">
                            <li><i class="flaticon-home"></i>72 Main Drive, Calibry, FL</li>
                            <li><i class="flaticon-open-email-message"></i><a href="mailto:admin@newriseimmigration.com">admin@newriseimmigration.com</a></li>
                            <li><i class="flaticon-clock"></i>Mon - Fri : 0900 to 1800</li>
                        </ul>
                    </div>
                    <div class="top-right pull-right">
                        <ul class="social-links clearfix">
                            <li><a href="index-2.html"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="index-2.html"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="index-2.html"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="index-2.html"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="index-2.html"><i class="fab fa-google-plus-g"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="header-upper">
                <div class="outer-container">
                    <div class="outer-box clearfix">
                        <div class="upper-left pull-left">
                            <figure class="logo-box"><a href="index-2.html"><img src="assets/images/logo.png" style="height:54px;" alt=""></a></figure>
                            <div class="btn-box"><a href="index-2.html" class="theme-btn-one">Appointment<i class="flaticon-send"></i></a></div>
                        </div>
                        <div class="menu-area pull-right">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="index.php">Home</a>
                                        </li> 
                                        <li><a href="about.php">About</a>                                            
                                        </li>
                                        <li class="dropdown"><a href="career.php">Career</a>
                                            
                                        </li>
                                        <li class="dropdown"><a href="index-2.html">Services</a>
                                           
                                        </li>
                                        <li class="dropdown"><a href="blogs.php">Blogs</a>
                                        </li> 
                                        <li><a href="contact.php">Contact</a></li>               
                                    </ul>
                                </div>
                            </nav>
                            <div class="menu-right-content clearfix pull-left">
                                <div class="">
                                    <!-- <div class="search-btn">
                                        <button type="button" class="search-toggler"><i class="flaticon-search-1"></i></button>
                                    </div> -->
                                </div>
                                <div class="support-box">
                                    <i class="fas fa-phone-volume"></i>
                                    <p>Any Questions? Call us</p>
                                    <h3><a href="tel:12463330079">+1 (246) 333 0079</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box clearfix">
                        <div class="logo-box pull-left">
                            <figure class="logo"><a href="index-2.html"><img src="assets/images/logo.png" style="height:45px;" alt=""></a></figure>
                        </div>
                        <div class="menu-area pull-right">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            <nav class="menu-box">
                <div class="nav-logo"><a href="index-2.html"><img src="assets/images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li>
                        <li><a href="mailto:info@example.com">info@example.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="index-2.html"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="index-2.html"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="index-2.html"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="index-2.html"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="index-2.html"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->

        