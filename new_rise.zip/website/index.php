<?php
$page_name = "Home";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php require_once'includes/header.php';?>     

</head>


<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">

    <?php require_once'includes/navbar.php';?>


    <!-- banner-section -->
        <section class="banner-section style-one">
            <div class="banner-carousel owl-theme owl-carousel owl-dots-none">
                <div class="slide-item">
                    <div class="image-layer" style="background-image:url(assets/images/banner/banner-1.jpg)"></div>
                    <div class="auto-container">
                        <div class="row clearfix">
                            <div class="col-xl-7 col-lg-12 col-md-12 content-column">
                                <div class="content-box">
                                    <div class="title-text">
                                        <h1>Our Simple Approach To Immigration Process</h1>
                                        <div class="dotted-box">
                                            <span class="dotted"></span>
                                            <span class="dotted"></span>
                                            <span class="dotted"></span>
                                        </div>
                                    </div>
                                    <p>Mod tempor incididunt ut laboret dolore magna aliqua tenim adnim veniam quis nostrud exercitation ullamco.</p>
                                    <div class="btn-box">
                                        <a href="index-2.html" class="theme-btn-one"><i class="flaticon-send"></i>Discover Solutions</a>
                                    </div>
                                </div> 
                            </div>
                        </div> 
                    </div>
                </div>
                <div class="slide-item">
                    <div class="image-layer" style="background-image:url(assets/images/banner/banner-2.jpg)"></div>
                    <div class="auto-container">
                        <div class="row clearfix">
                            <div class="col-xl-6 col-lg-12 col-md-12 content-column">
                                <div class="content-box">
                                    <span class="top-text">Effective Immigration Solution</span>
                                    <div class="title-text">
                                        <h1>Modern Immigration Firm With Savings</h1>
                                        <div class="dotted-box">
                                            <span class="dotted"></span>
                                            <span class="dotted"></span>
                                            <span class="dotted"></span>
                                        </div>
                                    </div>
                                    <div class="btn-box">
                                        <a href="index-2.html" class="theme-btn-one"><i class="flaticon-send"></i>Discover Solutions</a>
                                    </div>
                                </div> 
                            </div>
                        </div> 
                    </div>
                </div>
                <div class="slide-item">
                    <div class="image-layer" style="background-image:url(assets/images/banner/banner-3.jpg)"></div>
                    <div class="auto-container">
                        <div class="row clearfix">
                            <div class="col-xl-7 col-lg-12 col-md-12 content-column">
                                <div class="content-box">
                                    <span class="top-text">Effective Immigration Solution</span>
                                    <div class="title-text">
                                        <h1>Empowering Peoples Immigration Confidently</h1>
                                        <div class="dotted-box">
                                            <span class="dotted"></span>
                                            <span class="dotted"></span>
                                            <span class="dotted"></span>
                                        </div>
                                    </div>
                                    <div class="btn-box">
                                        <a href="index-2.html" class="theme-btn-one"><i class="flaticon-send"></i>Discover Solutions</a>
                                    </div>
                                </div> 
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </section>
        <!-- banner-section end -->


        <!-- about-section -->
        <?php require_once'includes/about.php';?>
         <!-- about-section end -->


        <!-- feature-section -->
        <?php require_once'includes/features.php';?>
        <!-- feature-section end -->


        <!-- cta-section -->
        <section class="cta-section bg-color-1 centred">
            <div class="auto-container">
                <div class="inner-box">
                    <h2>A CONVERSATION SHOULD ALWAYS BE FREE !</h2>
                    <div class="text">
                        <p>Now that you are here, Let’s talk about you, your goals, your plans, and your ambitions.</p>
                        <div class="dotted-box">
                            <div class="dotted"></div>
                            <div class="dotted"></div>
                            <div class="dotted"></div>
                            <div class="dotted"></div>
                            <div class="dotted"></div>
                            <div class="dotted"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- cta-section end -->


        <!-- service-section -->
        <section class="service-section">
            <div class="auto-container">
                <div class="top-inner">
                    <div class="row clearfix">
                        <div class="col-lg-5 col-md-12 col-sm-12 title-column">
                            <div class="sec-title">
                                <p>How we help clients</p>
                                <h2>Level With Great Visa Serving Policies</h2>
                                <div class="dotted-box">
                                    <span class="dotted"></span>
                                    <span class="dotted"></span>
                                    <span class="dotted"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-12 col-sm-12 text-column">
                            <div class="text">
                                <p>Sponsoring and managing work visas parts now becoming results the experience aute irure dolor in reprehenderit cepteur sint ocae cat cupidatat non proident sunt in culpa quis.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="four-item-carousel owl-carousel owl-theme owl-nav-none">
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-manager"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Working Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-flight"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Study Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-airport"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Business Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-bus-stop"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Tourist Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-manager"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Working Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-flight"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Study Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-airport"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Business Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-bus-stop"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Tourist Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-manager"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Working Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-flight"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Study Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-airport"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Business Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                    <div class="service-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-bus-stop"></i></div>
                            <span>visa types</span>
                            <h3><a href="service-details.html">Tourist Visas</a></h3>
                            <p>Nunc quam arc pretium quis lobortis sem consequat conse tetur diam nunc bibend.</p>
                            <div class="link"><a href="service-details.html"><i class="flaticon-send"></i></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- service-section end -->


        <!-- apply-section -->
        <section class="apply-section">
            <div class="auto-container">
                <div class="inner-box clearfix">
                    <figure class="image-box"><img src="assets/images/resource/apply-1.jpg" alt=""></figure>
                    <div class="content-box">
                        <div class="icon-box">
                            <div class="icon icon-1"></div>
                            <div class="icon icon-2"></div>
                        </div>
                        <h4>Get Free Online Visa Assessment Today!</h4>
                        <h2>Top Rated By Customers & Immigration Firms With 100% Success Rate.</h2>
                        <a href="index-2.html" class="theme-btn-one"><i class="flaticon-send"></i>Apply Visa Now</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- apply-section end -->


        <!-- funfact-section -->
        <section class="funfact-section centred">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 counter-block">
                        <div class="counter-block-one wow slideInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="1500" data-stop="560">0</span>
                                </div>
                                <h3>We Have Worked With Clients</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 counter-block">
                        <div class="counter-block-one wow slideInUp animated animated" data-wow-delay="200ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="1500" data-stop="99">0</span><span>%</span>
                                </div>
                                <h3>Successfull Visa Process Rate</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 counter-block">
                        <div class="counter-block-one wow slideInUp animated animated" data-wow-delay="400ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="1500" data-stop="42">0</span><span>hrs</span>
                                </div>
                                <h3>Application Approval Time We Follow</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- funfact-section end -->


        <!-- training-section -->
        <section class="training-section bg-color-2">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/pattern-2.png);"></div>
            <div class="auto-container">
                <div class="top-inner">
                    <div class="row clearfix">
                        <div class="col-lg-5 col-md-12 col-sm-12 title-column">
                            <div class="sec-title light">
                                <p>How we help clients</p>
                                <h2>Get The Immigration Training You Deserve</h2>
                                <div class="dotted-box">
                                    <span class="dotted"></span>
                                    <span class="dotted"></span>
                                    <span class="dotted"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-12 col-sm-12 text-column">
                            <div class="text">
                                <p>Sponsoring and managing work visas parts now becoming results the experience aute irure dolor in reprehenderit cepteur sint ocae cat cupidatat non proident sunt in culpa quis.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="four-item-carousel owl-carousel owl-theme owl-dots-none">
                    <div class="training-block-one">
                        <div class="inner-box">
                            <div class="content-box">
                                <figure class="image-box"><img src="assets/images/resource/training-1.jpg" alt=""></figure>
                                <div class="text"><h4>Citizenship Test</h4></div>
                            </div>
                            <div class="overlay-box">
                                <div class="text">
                                    <h4>Citizenship Test</h4>
                                    <p>Integer lobortis se conseqat nulla viverra lorem  dapibus prodent diam ipsum ...</p>
                                    <a href="index-2.html"><span>Read More</span><i class="flaticon-send"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="training-block-one">
                        <div class="inner-box">
                            <div class="content-box">
                                <figure class="image-box"><img src="assets/images/resource/training-2.jpg" alt=""></figure>
                                <div class="text"><h4>TOEFL</h4></div>
                            </div>
                            <div class="overlay-box">
                                <div class="text">
                                    <h4>TOEFL</h4>
                                    <p>Integer lobortis se conseqat nulla viverra lorem  dapibus prodent diam ipsum ...</p>
                                    <a href="index-2.html"><span>Read More</span><i class="flaticon-send"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="training-block-one">
                        <div class="inner-box">
                            <div class="content-box">
                                <figure class="image-box"><img src="assets/images/resource/training-3.jpg" alt=""></figure>
                                <div class="text"><h4>Take IELTS</h4></div>
                            </div>
                            <div class="overlay-box">
                                <div class="text">
                                    <h4>Take IELTS</h4>
                                    <p>Integer lobortis se conseqat nulla viverra lorem  dapibus prodent diam ipsum ...</p>
                                    <a href="index-2.html"><span>Read More</span><i class="flaticon-send"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="training-block-one">
                        <div class="inner-box">
                            <div class="content-box">
                                <figure class="image-box"><img src="assets/images/resource/training-4.jpg" alt=""></figure>
                                <div class="text"><h4>PTE Coaching</h4></div>
                            </div>
                            <div class="overlay-box">
                                <div class="text">
                                    <h4>PTE Coaching</h4>
                                    <p>Integer lobortis se conseqat nulla viverra lorem  dapibus prodent diam ipsum ...</p>
                                    <a href="index-2.html"><span>Read More</span><i class="flaticon-send"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- training-section end -->


        <!-- immigration-section -->
        <section class="immigration-section">
            <div class="auto-container">
                <div class="sec-title centred">
                    <p>countries we offer support</p>
                    <h2>Immigration & Visa Services <br />Following Countries</h2>
                    <div class="dotted-box">
                        <span class="dotted"></span>
                        <span class="dotted"></span>
                        <span class="dotted"></span>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 immigration-block">
                        <div class="immigration-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="assets/images/resource/immigration-1.jpg" alt=""></figure>
                                <div class="text">
                                    <h3><a href="index-2.html">United States</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 immigration-block">
                        <div class="immigration-block-one wow fadeInUp animated animated" data-wow-delay="200ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="assets/images/resource/immigration-2.jpg" alt=""></figure>
                                <div class="text">
                                    <h3><a href="index-2.html">Canada</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 immigration-block">
                        <div class="immigration-block-one wow fadeInUp animated animated" data-wow-delay="400ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="assets/images/resource/immigration-3.jpg" alt=""></figure>
                                <div class="text">
                                    <h3><a href="index-2.html">Australia</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 immigration-block">
                        <div class="immigration-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="assets/images/resource/immigration-4.jpg" alt=""></figure>
                                <div class="text">
                                    <h3><a href="index-2.html">NewZealand</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 immigration-block">
                        <div class="immigration-block-one wow fadeInUp animated animated" data-wow-delay="200ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="assets/images/resource/immigration-5.jpg" alt=""></figure>
                                <div class="text">
                                    <h3><a href="index-2.html">Europe</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 immigration-block">
                        <div class="immigration-block-one wow fadeInUp animated animated" data-wow-delay="400ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="assets/images/resource/immigration-6.jpg" alt=""></figure>
                                <div class="text">
                                    <h3><a href="index-2.html">United Kingdom</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="more-text"><h3>Visarzo is clearly your best partner at Immigration& Visa success. <a href="index-2.html"><span>Get In Touch</span><i class="flaticon-send"></i></a></h3></div>
            </div>
        </section>
        <!-- immigration-section end -->


        <!-- choose-section -->
        <section class="choose-section bg-color-3">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/pattern-3.png);"></div>
            <figure class="image-layer wow slideInRight animated animated" data-wow-delay="00ms" data-wow-duration="1500ms"><img src="assets/images/resource/choose-1.jpg" alt=""></figure>
            <div class="auto-container">
                <div id="content_block_2">
                    <div class="content-box">
                        <div class="sec-title">
                            <p>why choose visarzo</p>
                            <h2>Countless Benefits & Easy Processing</h2>
                            <div class="dotted-box">
                                <span class="dotted"></span>
                                <span class="dotted"></span>
                                <span class="dotted"></span>
                            </div>
                        </div>
                        <div class="text">
                            <p>Nunc quam arcu, pretium quis quam sed, laoreet efficitur leo. Aliquam era volutpat. lobortis sem consequat consequat imperdiet. In nulla sed viverraut loremut dapib es tetur diam nunc bibendum imperdiets.</p>
                        </div>
                        <div class="inner-box">
                            <div class="single-item">
                                <div class="icon-box"><i class="flaticon-air-freight"></i></div>
                                <h3>Legal Immigration Success</h3>
                                <p>Kaoreet efficitur leo. Aliquam era volutpat. lobortis sem consequat consequat imperdiet. In nulla sed viverraut loremut.</p>
                            </div>
                            <div class="single-item">
                                <div class="icon-box"><i class="flaticon-report"></i></div>
                                <h3>Required Documents Support</h3>
                                <p>Kaoreet efficitur leo. Aliquam era volutpat. lobortis sem consequat consequat imperdiet. In nulla sed viverraut loremut.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- choose-section end -->


        <!-- testimonial-section -->
        <section class="testimonial-section">
            <div class="auto-container">
                <div class="sec-title centred">
                    <p>clients testimonials</p>
                    <h2>What Customers <br />Saying About Visarzo</h2>
                    <div class="dotted-box">
                        <span class="dotted"></span>
                        <span class="dotted"></span>
                        <span class="dotted"></span>
                    </div>
                </div>
                <div class="two-column-carousel owl-carousel owl-theme owl-nav-none">
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="author-inner">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-1.png" alt=""></figure>
                                <h5>James Thomas</h5>
                                <span class="designation">California, USA</span>
                            </div>
                            <div class="content-inner">
                                <div class="rating-box">
                                    <h6>Green Card Approved</h6>
                                    <ul class="rating">
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="text">
                                    <p>Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret dolors magn aliquat enim sed minim veniam eu nostrud lorem ipsum dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="author-inner">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-2.png" alt=""></figure>
                                <h5>Tanya Benson</h5>
                                <span class="designation">California, USA</span>
                            </div>
                            <div class="content-inner">
                                <div class="rating-box">
                                    <h6>Canada Immigration</h6>
                                    <ul class="rating">
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="text">
                                    <p>Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret dolors magn aliquat enim sed minim veniam eu nostrud lorem ipsum dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="author-inner">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-1.png" alt=""></figure>
                                <h5>James Thomas</h5>
                                <span class="designation">California, USA</span>
                            </div>
                            <div class="content-inner">
                                <div class="rating-box">
                                    <h6>Green Card Approved</h6>
                                    <ul class="rating">
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="text">
                                    <p>Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret dolors magn aliquat enim sed minim veniam eu nostrud lorem ipsum dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="author-inner">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-2.png" alt=""></figure>
                                <h5>Tanya Benson</h5>
                                <span class="designation">California, USA</span>
                            </div>
                            <div class="content-inner">
                                <div class="rating-box">
                                    <h6>Canada Immigration</h6>
                                    <ul class="rating">
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="text">
                                    <p>Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret dolors magn aliquat enim sed minim veniam eu nostrud lorem ipsum dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="author-inner">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-1.png" alt=""></figure>
                                <h5>James Thomas</h5>
                                <span class="designation">California, USA</span>
                            </div>
                            <div class="content-inner">
                                <div class="rating-box">
                                    <h6>Green Card Approved</h6>
                                    <ul class="rating">
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="text">
                                    <p>Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret dolors magn aliquat enim sed minim veniam eu nostrud lorem ipsum dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="author-inner">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-2.png" alt=""></figure>
                                <h5>Tanya Benson</h5>
                                <span class="designation">California, USA</span>
                            </div>
                            <div class="content-inner">
                                <div class="rating-box">
                                    <h6>Canada Immigration</h6>
                                    <ul class="rating">
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                                <div class="text">
                                    <p>Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret dolors magn aliquat enim sed minim veniam eu nostrud lorem ipsum dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial-section end -->


        <!-- inquiry-section -->
        <section class="inquiry-section bg-color-1">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/pattern-4.png);"></div>
            <div class="auto-container">
                <div class="row align-items-center clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 inner-column">
                        <div class="inner-box">
                            <h4>Get Free Assessment Today!</h4>
                            <h2>Fell Free To Enquire About <br />Any Questions You Got</h2>
                            <form action="https://azim.commonsupport.com/Visarzo/index.html" method="post" class="inquiry-form">
                                <div class="form-group">
                                    <input type="text" name="name" placeholder="Full Name" required="">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Email address" required="">
                                </div>
                                <div class="form-group">
                                    <textarea name="message" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="theme-btn-two"><i class="flaticon-send"></i>Send Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <h3>Customer Ratings</h3>
                            <ul class="rating clearfix">
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                            </ul>
                            <h2>4.8 / 5.0</h2>
                            <span>By 1500+ Visa Approved Customers</span>
                            <ul class="info-box clearfix">
                                <li>
                                    <i class="flaticon-call"></i>
                                    <p>Any Questions? Call us</p>
                                    <h3><a href="tel:12463330079">+1 (246) 333 0079</a></h3>
                                </li>
                                <li>
                                    <i class="flaticon-email"></i>
                                    <p>Any Questions? Email us</p>
                                    <h3><a href="mailto:inquiry@example.com">inquiry@example.com</a></h3>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- inquiry-section end -->


        <!-- news-section -->
        <section class="news-section">
            <div class="auto-container">
                <div class="top-inner">
                    <div class="row clearfix">
                        <div class="col-lg-5 col-md-12 col-sm-12 title-column">
                            <div class="sec-title">
                                <p>How we help clients</p>
                                <h2>World Immigration News & Updates</h2>
                                <div class="dotted-box">
                                    <span class="dotted"></span>
                                    <span class="dotted"></span>
                                    <span class="dotted"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-12 col-sm-12 text-column">
                            <div class="text">
                                <p>Sponsoring and managing work visas parts now becoming results the experience aute irure dolor in reprehenderit cepteur sint ocae cat cupidatat non proident sunt in culpa quis.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><a href="blog-details.html"><img src="assets/images/news/news-1.jpg" alt=""></a></figure>
                                <div class="lower-content">
                                    <div class="post-date"><h2>18</h2><span>apr</span></div>
                                    <h3><a href="blog-details.html">Covid-19 And Its Impact On USA Immigration</a></h3>
                                    <ul class="post-info clearfix">
                                        <li><a href="index-2.html">By Admin</a></li>
                                        <li><a href="index-2.html">Study Visa</a>,<a href="index-2.html">Work</a></li>
                                    </ul>
                                    <div class="link"><a href="blog-details.html">Learn More<i class="flaticon-send"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><a href="blog-details.html"><img src="assets/images/news/news-2.jpg" alt=""></a></figure>
                                <div class="lower-content">
                                    <div class="post-date"><h2>17</h2><span>apr</span></div>
                                    <h3><a href="blog-details.html">UK To Offers Point-Based Immigration Process</a></h3>
                                    <ul class="post-info clearfix">
                                        <li><a href="index-2.html">By Admin</a></li>
                                        <li><a href="index-2.html">Europe Permit</a></li>
                                    </ul>
                                    <div class="link"><a href="blog-details.html">Learn More<i class="flaticon-send"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><a href="blog-details.html"><img src="assets/images/news/news-3.jpg" alt=""></a></figure>
                                <div class="lower-content">
                                    <div class="post-date"><h2>16</h2><span>apr</span></div>
                                    <h3><a href="blog-details.html">Kickstart Your Visa ApprovalWith 4 Easy Steps</a></h3>
                                    <ul class="post-info clearfix">
                                        <li><a href="index-2.html">By Admin</a></li>
                                        <li><a href="index-2.html">Immigration</a></li>
                                    </ul>
                                    <div class="link"><a href="blog-details.html">Learn More<i class="flaticon-send"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- news-section end -->


        <!-- clients-section -->
        <section class="clients-section">
            <div class="auto-container">
                <div class="four-item-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
                    <figure class="logo-image"><a href="index-2.html"><img src="assets/images/clients/clients-logo-1.png" alt=""></a></figure>
                    <figure class="logo-image"><a href="index-2.html"><img src="assets/images/clients/clients-logo-2.png" alt=""></a></figure>
                    <figure class="logo-image"><a href="index-2.html"><img src="assets/images/clients/clients-logo-3.png" alt=""></a></figure>
                    <figure class="logo-image"><a href="index-2.html"><img src="assets/images/clients/clients-logo-4.png" alt=""></a></figure>
                </div>
            </div>
        </section>
        <!-- clients-section end -->


        <!-- main-footer -->
        <footer class="main-footer bg-color-2">
            <div class="auto-container">
                <div class="footer-top">
                    <div class="widget-section">
                        <div class="row clearfix">
                            <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                                <div class="footer-widget logo-widget">
                                    <figure class="footer-logo"><a href="index-2.html"><img src="assets/images/footer-logo.png" alt=""></a></figure>
                                    <div class="text">
                                        <p>Integer lobortis sem consequat imperdiet In nulla viverra ut lorem ut, dapibus conse etur diam. Nun bibendum diet condiment sed ipsum duis lacinia.</p>
                                    </div>
                                    <ul class="social-links clearfix">
                                        <li><a href="index-2.html"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="index-2.html"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="index-2.html"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="index-2.html"><i class="fab fa-google-plus-g"></i></a></li>
                                        <li><a href="index-2.html"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                                <div class="footer-widget links-widget">
                                    <div class="widget-title">
                                        <h3>Immigration</h3>
                                    </div>
                                    <div class="widget-content">
                                        <ul class="list clearfix">
                                            <li><a href="index-2.html">Pre Assessment</a></li>
                                            <li><a href="index-2.html">Visa Consultation</a></li>
                                            <li><a href="index-2.html">Business Plans</a></li>
                                            <li><a href="index-2.html">Post Landing Assistant</a></li>
                                            <li><a href="index-2.html">Meet Our Agents</a></li>
                                            <li><a href="index-2.html">Visa Documentation</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                                <div class="footer-widget links-widget">
                                    <div class="widget-title">
                                        <h3>Quick Links</h3>
                                    </div>
                                    <div class="widget-content">
                                        <ul class="list clearfix">
                                            <li><a href="index-2.html">About Visarzo</a></li>
                                            <li><a href="index-2.html">Why Immigrate</a></li>
                                            <li><a href="index-2.html">Service Features</a></li>
                                            <li><a href="index-2.html">Study Visas</a></li>
                                            <li><a href="index-2.html">Apply As Citizenship</a></li>
                                            <li><a href="index-2.html">Immigration Resources</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                                <div class="footer-widget newsletter-widget">
                                    <div class="widget-title">
                                        <h3>Newsletter Signup</h3>
                                    </div>
                                    <div class="widget-content">
                                        <p>Enter your email address to get latest updates and offers from us. Also some Discount coupons.</p>
                                        <form action="https://azim.commonsupport.com/Visarzo/index.html" method="post" class="newsletter-form">
                                            <div class="form-group">
                                                <input type="email" name="email" placeholder="Email address" required="">
                                                <button type="submit"><i class="flaticon-send"></i></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom clearfix">
                    <div class="copyright pull-left"><p>(&copy;) 2020 <a href="index-2.html">VISARZO</a> Immigration & Visa Firm. All rights reserved.</p></div>
                    <ul class="footer-nav pull-right clearfix"> 
                        <li><a href="index-2.html">Privacy Policy</a></li>
                        <li><a href="index-2.html">Sitemap</a></li>
                        <li><a href="index-2.html">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
        </footer>
        <!-- main-footer end -->


        <!--Scroll to top-->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="fas fa-long-arrow-alt-up"></i>            
        </button>
        
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/jQuery.style.switcher.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>
</body><!-- End of .page_wrapper -->

</html>
