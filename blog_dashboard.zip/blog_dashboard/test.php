<?php
require_once 'backend/connection.php';

$sql = "select category from blogs";
$query = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($query)){
    echo $row['category'];
}