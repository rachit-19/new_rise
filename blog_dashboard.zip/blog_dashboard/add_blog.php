<?php
    session_start();
    if($_SESSION['user_id'] == null) header("location: login.php"); 
?>

<!DOCTYPE html>
    <html lang="en">

<head>
        <meta charset="utf-8" />
        <title>Add Blog | New Rise Admin</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>
        

        
    </head>

    <body class="loading" data-layout-color="light" data-leftbar-theme="dark" data-layout-mode="fluid" data-rightbar-onstart="true">
        <!-- Begin page -->
        <div class="wrapper">
            <!-- ========== Left Sidebar Start ========== -->
            <?php require_once 'includes/sidebar.php'; ?>
           <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <?php require_once 'includes/topbar.php'; ?>
                    <!-- end Topbar -->
                    
                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Add Blog</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    <div class="row" id="connection"></div>
                                        <form action="" id="addBlog" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="title" class="form-control-label">Add Title</label>
                                                    <input type="text" class="form-control" id="title">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="category" class="form-control-label">Add Category</label>
                                                    <input type="text" class="form-control" id="category">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="photo" class="form-control-label">Add Photo</label>
                                                    <input type="file" class="form-control" id="photo">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="tags" class="form-control-label">Add Tags</label>
                                                    <input type="text" class="form-control" id="tags">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="para1" class="form-control-label mb-1">Add Paragraph 1</label>
                                                    <textarea id="para1" rows="3" class="form-control"></textarea>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="para2" class="form-control-label mb-1">Add Paragraph 2</label>
                                                    <textarea id="para2" rows="3" class="form-control"></textarea>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="para3" class="form-control-label mb-1">Add Paragraph 3</label>
                                                    <textarea id="para3" rows="3" class="form-control"></textarea>
                                                </div>
                                            </div>

                                            <hr>

                                            <div class="row">
                                                <div class="col-11"></div>
                                                <div class="col float-right">
                                                    <button class="btn btn-success">Add</button>
                                                </div>
                                            </div>
                                            
                                                
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                
                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                <!-- Footer Start -->
                <?php require_once 'includes/footer.php';?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- bundle -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>

        <script src="assets/js/sweet-alert.js"></script>


        


        <script>
            $(document).ready(function(){
                $("#addBlog").submit(function(event){
                    event.preventDefault();

                    var formData = {
                        title: $("#title").val(),
                        category: $("#category").val(),
                        image: "photo",
                        tags: $("#tags").val(),
                        para1: $("#para1").val(),
                        para2: $("#para2").val(),
                        para3: $("#para3").val()
                    };
                    console.log(formData);

                    $.ajax({
                        method: "POST",
                        url: "./backend/add_blog.php",
                        data: formData,
                        mimeType: "multipart/form-data",
                        dataType: "json",
                        encode: true
                    }).done(function(data){
                        console.log(data);
                        if(!data.success){
                            if(data.errors.title){
                                $("#title").addClass("is-invalid");
                            }
                            if(data.errors.category){
                                $("#category").addClass("is-invalid");
                            }
                            if(data.errors.image){
                                $("#photo").addClass("is-invalid");
                            }
                            if(data.errors.tags){
                                $("#tags").addClass("is-invalid");
                            }
                            if(data.errors.para1){
                                $("#para1").addClass("is-invalid");
                            }
                            if(data.errors.connection){
                                $("#connection").append('<div class="alert alert-danger" role="alert"><i class="dripicons-wrong me-2"></i>'+ data.errors.connection +'</div>');
                            }
                        }
                        else{
                            Swal.fire(
                                'Success😁',
                                'Blog was added successfully.',
                                'success'
                            );

                            $("#addBlog")[0].reset();

                        }
                    });
                   
                });
            });


            $("#title").change(function(){
                $("#title").removeClass("is-invalid")
            });
            $("#category").change(function(){
                $("#category").removeClass("is-invalid")
            });
            $("#photo").change(function(){
                $("#photo").removeClass("is-invalid")
            });
            $("#tags").change(function(){
                $("#tags").removeClass("is-invalid")
            });
            $("#para1").change(function(){
                $("#para1").removeClass("is-invalid")
            });
        </script>

     
    </body>

</html>