<?php
    session_start();
    if($_SESSION['user_id'] == null) header("location: login.php");

    if($_GET['id'] == null) header("location: manage_blogs.php");
    
    else $_SESSION['blog_id'] = $_GET['id'];
?>

<!DOCTYPE html>
    <html lang="en">

<head>
        <meta charset="utf-8" />
        <title>Edit Blog | New Rise Admin</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>
        

        
    </head>

    <body class="loading" data-layout-color="light" data-leftbar-theme="dark" data-layout-mode="fluid" data-rightbar-onstart="true">
        <!-- Begin page -->
        <div class="wrapper">
            <!-- ========== Left Sidebar Start ========== -->
            <?php require_once 'includes/sidebar.php'; ?>
           <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <?php require_once 'includes/topbar.php'; ?>
                    <!-- end Topbar -->
                    
                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Edit Blog</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    <div class="row" id="connection"></div>
                                        <form action="" id="updateBlog" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="title" class="form-control-label">Edit Title</label>
                                                    <input type="text" class="form-control" id="title">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="category" class="form-control-label">Edit Category</label>
                                                    <input type="text" class="form-control" id="category">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2 mb-3">
                                                <label for="image" class="form-control-label">Selected Photo</label>
                                                <img src="assets/images/small/small-1.jpg" id="image" alt="..." class="img-thumbnail">

                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="photo" class="form-control-label">Edit Photo</label>
                                                    <input type="file" class="form-control" id="photo">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="tags" class="form-control-label">Edit Tags</label>
                                                    <input type="text" class="form-control" id="tags">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="para1" class="form-control-label mb-1">Edit Paragraph 1</label>
                                                    <textarea id="para1" rows="3" class="form-control"></textarea>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="para2" class="form-control-label mb-1">Edit Paragraph 2</label>
                                                    <textarea id="para2" rows="3" class="form-control"></textarea>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="para3" class="form-control-label mb-1">Edit Paragraph 3</label>
                                                    <textarea id="para3" rows="3" class="form-control"></textarea>
                                                </div>
                                            </div>

                                            <hr>

                                            <div class="row">
                                                <div class="col-11"></div>
                                                <div class="col float-right">
                                                    <button class="btn btn-success">Update</button>
                                                </div>
                                            </div>
                                            
                                                
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                
                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                <!-- Footer Start -->
                <?php require_once 'includes/footer.php';?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- bundle -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>

        <script src="assets/js/sweet-alert.js"></script>

       <script>
          
        var tempReadData = {};            
             
        function read(){
          $.ajax({
                method: "POST",
                url: "./backend/read_blog.php",
                data: {"data_id": <?php echo $_GET['id']?>},
                mimeType: "multipart/form-data",
                dataType: "json",
                encode: true 
                        
             }).done(function(data){
                 
                var title = document.getElementById("title");
                title.setAttribute("value", data.title);

                var category = document.getElementById("category");
                category.setAttribute("value", data.category);

                var image = document.getElementById("photo");
                image.setAttribute("value", data.image);

                var tags = document.getElementById("tags");
                tags.setAttribute("value", data.tags);

                $("#para1").append(data.para1);

                $("#para2").append(data.para2);

                $("#para3").append(data.para3);
                tempReadData = data;
                //getData(data);
            });             
             
        }
        read();
        $(document).ready(function(){
                $("#updateBlog").submit(function(event){
                    var formData = {
                        title: $("#title").val(),
                        category: $("#category").val(),
                        image: "photo",
                        tags: $("#tags").val(),
                        para1: $("#para1").val(),
                        para2: $("#para2").val(),
                        para3: $("#para3").val()
                    };                   
                    
                    event.preventDefault();
                    
                    if(JSON.stringify(formData) == JSON.stringify(tempReadData)){
                        Swal.fire(
                            'No changes!',
                            '',
                            'warning'
                        )
                    }
                    else{
                        Swal.fire({
                            title: 'Do you want to save the changes?',
                            showDenyButton: true,
                            confirmButtonText: 'Save',
                            denyButtonText: `Don't save`,
                            icon : 'warning'
                            }).then((result) => {
                            /* Read more about isConfirmed, isDenied below */
                            if (result.isConfirmed) {                                
                                $.ajax({
                                    method: "POST",
                                    url: "./backend/update_blog.php",
                                    data: formData,
                                    mimeType: "multipart/form-data",
                                    dataType: "json",
                                    encode: true
                                }).done(function(data){
                                    if(!data.success){
                                        if(data.errors.title){
                                            $("#title").addClass("is-invalid");
                                        }
                                        if(data.errors.category){
                                            $("#category").addClass("is-invalid");
                                        }
                                        if(data.errors.image){
                                            $("#photo").addClass("is-invalid");
                                        }
                                        if(data.errors.tags){
                                            $("#tags").addClass("is-invalid");
                                        }
                                        if(data.errors.para1){
                                            $("#para1").addClass("is-invalid");
                                        }
                                        if(data.errors.connection){
                                            $("#connection").append('<div class="alert alert-danger" role="alert"><i class="dripicons-wrong me-2"></i>'+ data.errors.connection +'</div>');
                                        }
                                    }
                                    else{
                                        Swal.fire('Saved!', '', 'success')
                                    }
                                 });
                               
                            } else if (result.isDenied) {
                                Swal.fire('Changes are not saved', '', 'error')
                            }
                            })

                    }
                });
                
            });

            $("#title").change(function(){
                $("#title").removeClass("is-invalid")
            });
            $("#category").change(function(){
                $("#category").removeClass("is-invalid")
            });
            $("#photo").change(function(){
                $("#photo").removeClass("is-invalid")
            });
            $("#tags").change(function(){
                $("#tags").removeClass("is-invalid")
            });
            $("#para1").change(function(){
                $("#para1").removeClass("is-invalid")
            });
            
        </script>

     
    </body>

</html>