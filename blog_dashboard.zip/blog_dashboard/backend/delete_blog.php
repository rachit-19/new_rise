<?php

require_once 'connection.php';

$delete_id = $_POST['delete_id'];
$query = mysqli_query($conn, "DELETE FROM blogs WHERE id='$delete_id'");
