<?php 
require_once('connection.php');
$id = $_POST['data_id'];

$query = mysqli_query($conn, "SELECT title, category, image, tags, para1, para2, para3 FROM blogs where id='$id'");
$row = mysqli_fetch_assoc($query);

echo json_encode($row);
