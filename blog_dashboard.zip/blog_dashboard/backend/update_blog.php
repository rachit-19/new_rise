<?php
require_once 'connection.php';
session_start();
$blog_id = $_SESSION['blog_id'];
$data = [];
$errors = [];
if(!$conn){
    $errors['connection'] = "Unable to connect to database";
}
if(empty($_POST['title'])){
    $errors['title'] = "Please enter blog title.";
}

if(empty($_POST['category'])){
    $errors['category'] = "Please enter blog category.";
}

if(empty($_POST['image'])){
    $errors['image'] = "Please upload image.";
}

if(empty($_POST['tags'])){
    $errors['tags'] = "Please enter blog tags.";
}

if(empty($_POST['para1'])){
    $errors['para1'] = "Please enter atleast one blog paragraph.";
}



if (!empty($errors)) {
    $data['success'] = false;
    $data['errors'] = $errors;
}
else{
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $image = $_POST['image'];
    $tags = mysqli_real_escape_string($conn, $_POST['tags']);
    $para1 = mysqli_real_escape_string($conn, $_POST['para1']);
    $para2 = mysqli_real_escape_string($conn, $_POST['para2']);
    $para3 = mysqli_real_escape_string($conn, $_POST['para3']);

    $sql = "update blogs set title = '$title', category = '$category', image = '$image', tags = '$tags', para1 = '$para1', para2 = '$para2', para3 = '$para3' where id = '$blog_id'";
    $query = mysqli_query($conn, $sql);

    if($query == true){
        if(empty($errors)){
            $data['success'] = true;
            $data['message'] =  "Success!";
        }
    }
}
echo json_encode($data);