<?php
require_once 'connection.php';
$sql = "select * from messages order by id desc";
$query = mysqli_query($conn, $sql);
?>

<table id= "blogsTable" class="table mb-0 table-bordered">
    <thead class="table-dark">
        <tr>    
            <th>#</th>
            <th>Name</th>           
            <th>Contact</th>
            <th>Messaged On</th>
            <th>Message</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php 
            $count = 0;
            while($row = mysqli_fetch_assoc($query)){
                $count +=1;
                $date = strtotime($row['datetime']);
                $date = date("d M Y", $date);

                $message = explode(" ", $row["message"]);
                $message = implode(" ", array_splice($message, 0, 5));
        ?>
        <tr id="delete<?php echo $row['id']; ?>">
            <td><?php echo $count;?></td>
            <td><?php echo $row['fname'];?> <?php echo $row['lname'];?></td>           
            <td>
                <ul>
                    <li><?php echo $row['email'];?></li>
                    <li><?php echo $row['phone'];?></li>
                </ul>               
            </td>
            <td><?php echo $date; ?></td>
            <td><?php echo $message;?>... <a href="" data-bs-toggle="modal" data-bs-target="#info-header-modal<?php echo $row['id'];?>">view full message.</a></td>
            <td>
                <button type="button" class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"> Actions <i class="dripicons-gear"></i> <span class="caret"></span></button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="mailto:<?php echo $row['email'];?>" >Message <i class="dripicons-mail"></i></a>
                        <button class="dropdown-item" onclick = "deleteAjax(<?php echo $row['id']; ?>)" data-id="<?php echo $row['id']; ?>">Delete Message <i class="dripicons-trash"></i></button>
                    </div>
            </td>
        </tr>
        <div id="info-header-modal<?php echo $row['id'];?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="info-header-modalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header modal-colored-header bg-info">
                        <h4 class="modal-title" id="info-header-modalLabel">Message</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                    </div>
                    <div class="modal-body"> 
                        <?php echo $row['message'];?>               
                    </div>
            
                </div>
            </div>
        </div>
        <?php } ?>
    </tbody>
</table> 

<script src="./assets/js/sweet-alert.js"></script>


<script>
  function deleteAjax(id){
                const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
                });

                swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
                }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({

                type:'post',
                url:'./backend/delete_message.php',
                data:{delete_id:id},
                success:function(data){

                    $('#delete'+id).hide('slow');
                    swalWithBootstrapButtons.fire(
                        'Deleted!',
                        'The blog has been deleted.',
                        'success'
                    )
                    records();
                }

                });
   
            } else if (
                /* Read more about handling dismissals below */
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire(
                'Cancelled',
                'Dismissed the function.',
                'error'
                )
            }
            });
            }
</script>


        <script src="./assets/js/vendor/jquery.dataTables.min.js"></script>
        <script src="./assets/js/vendor/dataTables.bootstrap5.js"></script>
        <script src="./assets/js/vendor/dataTables.responsive.min.js"></script>
        <script src="./assets/js/vendor/responsive.bootstrap5.min.js"></script>
        <script>
            $('#blogsTable').dataTable( {
                
            } );
        </script>