<?php
require_once 'connection.php';
$sql = "select * from blogs";
$query = mysqli_query($conn, $sql);
?>

<table id= "blogsTable" class="table mb-0 table-bordered table-responsive">
    <thead class="table-dark">
        <tr>    
            <th>#</th>
            <th>Title</th>
            <th>Category</th>
            <th>Tags</th>
            <th>Published on</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php 
            $count = 0;
            while($row = mysqli_fetch_assoc($query)){
                $count +=1;
                $date = strtotime($row['date']);
                $date = date("d M Y", $date);
        ?>
        <tr id="delete<?php echo $row['id']; ?>">
            <td><?php echo $count; ?></td>
            <td><?php echo $row['title'];?></td>
            <td><?php echo $row['category'];?></td>
            <td><?php echo $row['tags'];?></td>
            <td><?php echo $date; ?></td>
            <td>
                <button type="button" class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"> Actions <i class="dripicons-gear"></i> <span class="caret"></span></button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="edit.php?id=<?php echo $row['id']?>" >Edit Blog <i class="dripicons-document-edit"></i></a>
                        <button class="dropdown-item" onclick = "deleteAjax(<?php echo $row['id']; ?>)" data-id="<?php echo $row['id']; ?>">Delete Blog <i class="dripicons-trash"></i></button>
                    </div>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table> 

<script src="./assets/js/sweet-alert.js"></script>


<script>
  function deleteAjax(id){
                const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
                });

                swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
                }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({

                type:'post',
                url:'./backend/delete_blog.php',
                data:{delete_id:id},
                success:function(data){

                    $('#delete'+id).hide('slow');
                    swalWithBootstrapButtons.fire(
                        'Deleted!',
                        'The blog has been deleted.',
                        'success'
                    )
                    records();
                }

                });
   
            } else if (
                /* Read more about handling dismissals below */
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire(
                'Cancelled',
                'Dismissed the function.',
                'error'
                )
            }
            });
            }
</script>


        <script src="./assets/js/vendor/jquery.dataTables.min.js"></script>
        <script src="./assets/js/vendor/dataTables.bootstrap5.js"></script>
        <script src="./assets/js/vendor/dataTables.responsive.min.js"></script>
        <script src="./assets/js/vendor/responsive.bootstrap5.min.js"></script>
        <script>
            $('#blogsTable').dataTable( {
                
            } );
        </script>