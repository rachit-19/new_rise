<?php
require_once 'connection.php';

$errors = [];
$data = [];

if(empty($_POST['email'])){
    $errors['email'] = "Please enter email id";
}

if(empty($_POST['password'])){
    $errors['password'] = "Please enter password";
}

if (!empty($errors)) {
    $data['success'] = false;
    $data['errors'] = $errors;
} 

else {
    $email = $_POST['email'];
    $password = $_POST['password'];    
    
    $sql = "select * from users where email = '$email' and password = '$password'";
    $query = mysqli_query($conn, $sql);
    $result = mysqli_fetch_assoc($query);

    if(!empty($result)){
        $data['success'] = true;
        $data['message'] =  "Success!";
        session_start();
        $_SESSION['user_id'] = $result['id'];
        $_SESSION['username'] = $result['username'];
    } else if(empty($result)) {
        $errors['login'] = "Username or password didn't matched!";
        $data['success'] = false;
        $data['errors'] = $errors;
    }
}

echo json_encode($data);

