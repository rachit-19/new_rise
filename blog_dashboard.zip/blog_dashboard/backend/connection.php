<?php 

// Connection credentials
$server = "localhost";
$username = "root";
$password = "";
$db_name = "new_rise";

// Connecting to database
$conn = mysqli_connect($server, $username, $password, $db_name);

