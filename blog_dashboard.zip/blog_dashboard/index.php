<?php
    session_start();
    if($_SESSION['user_id'] == null) header("location: login.php"); 
    require_once './backend/connection.php';

    $sqlMessages = "select * from messages";
    $queryMessages = mysqli_query($conn, $sqlMessages);
    $messages = mysqli_num_rows($queryMessages);

    $sqlBlogs = "select * from blogs";
    $queryBlogs = mysqli_query($conn, $sqlBlogs);
    $blogs = mysqli_num_rows($queryBlogs);
?>

<!DOCTYPE html>
    <html lang="en">

    
<!-- Mirrored from coderthemes.com/hyper/saas/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 27 Apr 2022 18:15:26 GMT -->
<head>
        <meta charset="utf-8" />
        <title>Dashboard | New Rise Admin</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>

    </head>

    <body class="loading" data-layout-color="light" data-leftbar-theme="dark" data-layout-mode="fluid" data-rightbar-onstart="true">
        <!-- Begin page -->
        <div class="wrapper">
            <!-- ========== Left Sidebar Start ========== -->
            <?php require_once 'includes/sidebar.php'; ?>
           <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <?php require_once 'includes/topbar.php'; ?>
                    <!-- end Topbar -->
                    
                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        <div class="row">
                            <div class="col-xl-3 col-lg-4">
                                <div class="card tilebox-one">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-end"></i>
                                        <h6 class="text-uppercase mt-0">No. of messages</h6>
                                        <h2 class="my-2" id="active-users-count"><?php echo $messages; ?></h2>
                                        <p class="mb-0 text-muted">
                                            
                                            <span class="text-nowrap"><a href="./view_messages.php">View messages</a></span>  
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>
                                <!--end card-->

                                <div class="card tilebox-one">
                                    <div class="card-body">
                                        <i class="uil uil-window-restore float-end"></i>
                                        <h6 class="text-uppercase mt-0">No. of blogs</h6>
                                        <h2 class="my-2" id="active-views-count"><?php echo $blogs; ?></h2>
                                        <p class="mb-0 text-muted">
                                            
                                            <span class="text-nowrap"><a href="./manage_blogs.php">View blogs</a></span>
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>
                                <!--end card-->

                                <div class="card cta-box overflow-hidden">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <a href="mailto:support@webmaze.in" style="color : #2d3238;"><h3 class="m-0 fw-normal cta-box-title">Reach out <b>support</b> for any issues <i class="mdi mdi-arrow-right"></i></h3></a>
                                            </div>
                                            <img class="ms-3" src="assets/images/email-campaign.svg" width="92" alt="Generic placeholder image">
                                        </div>
                                    </div>
                                    <!-- end card-body -->
                                </div>
                            </div> <!-- end col -->

                            <div class="col-xl-9 col-lg-8">
                                <div class="card card-h-100">
                                    <div class="card-body">
                                        <div class="card-title"><b>Latest messages</b></div>
                                        <table class="table table-responsive table-bordered table-responsive">
                                            <tr class="table-dark">
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Phone</th>
                                                <th>Email</th>
                                                <th>Messages</th>
                                            </tr>
                                            <?php
                                            $sql = "select * from messages order by id desc limit 4";
                                            $query = mysqli_query($conn, $sql);
                                            $count = 0;
                                            while($row = mysqli_fetch_assoc($query)){
                                                $count += 1;
                                            ?>
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td><?php echo ucwords($row['fname']).' '.ucwords($row['lname']);?></td>
                                                <td><?php echo $row['phone'];?></td>
                                                <td><?php echo $row['email'];?></td>
                                                <td><a href="" data-bs-toggle="modal" data-bs-target="#info-header-modal<?php echo $row['id'];?>">View Message.</a></td>
                                            </tr>
                                            <div id="info-header-modal<?php echo $row['id'];?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="info-header-modalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header modal-colored-header bg-info">
                                                            <h4 class="modal-title" id="info-header-modalLabel">Message</h4>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                                                        </div>
                                                        <div class="modal-body"> 
                                                            <?php echo $row['message'];?>               
                                                        </div>
                                                
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                            <tr>
                                                <td colspan="5">
                                                    <div class="text-center">
                                                        <a href="./view_messages.php" class="btn btn-link">View all messages.</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h4>Latest Blogs</h4>
                                        </div>
                                        <table class="table table-responsive table-bordered">
                                            <thead>
                                                <tr class="table-dark">
                                                    <th>#</th>
                                                    <th>Title</th>
                                                    <th>Category</th>
                                                    <th>Tags</th>
                                                    <th>Published on</th>
                                                    <th>View blog</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sql = "select * from blogs order by id desc limit 4";
                                                $query = mysqli_query($conn, $sql);
                                                $count = 0;
                                                while($row = mysqli_fetch_assoc($query)){
                                                    $count += 1;
                                                    $date = strtotime($row['date']);
                                                    $date = date("d M Y", $date);
                                                ?>
                                                <tr>
                                                    <td><?php echo $count; ?></td>
                                                    <td><?php echo $row['title']; ?></td>
                                                    <td><?php echo $row['category']; ?></td>
                                                    <td><?php echo $row['tags']; ?></td>
                                                    <td><?php echo $date; ?></td>
                                                    <td><a href="" class="btn btn-link">View blog</a></td>
                                                </tr>
                                                <?php } ?>
                                                <tr>
                                                    <td colspan="6">
                                                        <div class="text-center">
                                                            <a href="./manage_blogs.php" class="btn btn-link">View all blogs.</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                
                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                <!-- Footer Start -->
                <?php require_once 'includes/footer.php';?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- bundle -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>

        

        <!-- demo app -->
        <!-- end demo js-->
    </body>

<!-- Mirrored from coderthemes.com/hyper/saas/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 27 Apr 2022 18:16:11 GMT -->
</html>